num = float(input('Enter a number:'))
num_cube = num*num*num
print('The cube of the number is:', num_cube)