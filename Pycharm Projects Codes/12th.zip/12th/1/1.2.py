num=float(input('Enter a number:'))
num_sqrt=num**0.5
print('The square root of number is', num_sqrt)