for i in range(15,18):
    print("Cube of number", i, end=' ')
    print("is",i**3)