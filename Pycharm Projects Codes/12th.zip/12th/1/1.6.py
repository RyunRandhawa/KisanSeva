for i in range(1,18,2):
    print("Sq. root of", i, ":", (i**0.5))