import random
a=random.randint(1,6)
print(a)